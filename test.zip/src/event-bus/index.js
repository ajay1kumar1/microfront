import Eev from 'eev'

export const e = new Eev()

export default e
