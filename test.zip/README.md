## Running the app
#### Clone the code 
```bash
git clone https://github.com/IvanJov/microfront.git && cd microfront
```

#### Install dependencies
```bash
npm install
```

#### Run app
```bash
npm start
```

#### Open `http://localhost:9090/#/` in browser

You should see something like this:

https://raw.githubusercontent.com/ajay1kumar1/microfront